from rest_framework import viewsets, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Video
from .serializers import VideoSerializer
from .tasks import generate_thumbnail_async
from django.db.models import Q

class VideoViewSet(viewsets.ModelViewSet):
    serializer_class = VideoSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]
    queryset = Video.objects.all()
    def perform_create(self, serializer):
        video = serializer.save(owner=self.request.user)
        try:
            generate_thumbnail_async.delay(video.id)
        except Exception:
            pass
    @action(detail=True, methods=['POST'])
    def like(self, request, pk=None):
        video = self.get_object()
        user = request.user
        if user in video.likes.all():
            video.likes.remove(user)
            return Response({'liked': False})
        else:
            video.likes.add(user)
            return Response({'liked': True})
    @action(detail=True, methods=['POST'])
    def view(self, request, pk=None):
        video = self.get_object()
        video.views += 1
        video.save()
        return Response({'views': video.views})
    @action(detail=False, methods=['GET'])
    def search(self, request):
        q = request.query_params.get('q', '')
        videos = Video.objects.filter(Q(title__icontains=q) | Q(description__icontains=q))
        serializer = VideoSerializer(videos, many=True, context={'request': request})
        return Response(serializer.data)
