from celery import shared_task
from .models import Video
import os, tempfile
try:
    from moviepy.editor import VideoFileClip
    from django.core.files.base import ContentFile
    from PIL import Image
except Exception:
    VideoFileClip = None
@shared_task
def generate_thumbnail_async(video_id):
    try:
        video = Video.objects.get(id=video_id)
        if not VideoFileClip:
            return
        video_path = video.file.path
        with tempfile.NamedTemporaryFile(suffix='.jpg', delete=False) as tmp:
            clip = VideoFileClip(video_path)
            frame = clip.get_frame(1)
            clip.close()
            image = Image.fromarray(frame)
            image.save(tmp.name)
            with open(tmp.name, 'rb') as f:
                video.thumbnail.save(os.path.basename(tmp.name), ContentFile(f.read()))
            os.unlink(tmp.name)
    except Exception as e:
        print('Thumbnail generation failed:', e)
