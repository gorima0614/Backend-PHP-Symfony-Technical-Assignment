from rest_framework import serializers
from .models import Video

class VideoSerializer(serializers.ModelSerializer):
    owner = serializers.StringRelatedField(read_only=True)
    likes_count = serializers.SerializerMethodField()
    class Meta:
        model = Video
        fields = '__all__'
        read_only_fields = ('owner','views','likes','thumbnail')
    def get_likes_count(self, obj):
        return obj.likes.count()
