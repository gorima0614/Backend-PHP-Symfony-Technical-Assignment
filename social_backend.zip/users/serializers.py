from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Profile

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'username', 'email')

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=8)
    class Meta:
        model = User
        fields = ('id','username','email','password')
    def create(self, validated_data):
        user = User.objects.create_user(username=validated_data['username'], email=validated_data.get('email',''), password=validated_data['password'])
        return user

class ProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    followers_count = serializers.IntegerField(source='followers.count', read_only=True)
    following_count = serializers.SerializerMethodField()
    class Meta:
        model = Profile
        fields = ('user','display_name','bio','avatar','location','followers_count','following_count')
    def get_following_count(self, obj):
        return obj.following.count()
